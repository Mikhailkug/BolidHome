package ru.bolid.home

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bolid_home_demo", MODE_PRIVATE)
        setContent { BolidApp(prefs) }
    }
}

private enum class Section(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    FIRE("Пожарная сигнализация", Icons.Default.LocalFireDepartment),
    SECURITY("Охранная сигнализация", Icons.Default.Security),
    ACCESS("Доступ", Icons.Default.DoorFront),
    ACTUATORS("Исполнительные устройства", Icons.Default.Tune)
}

private data class Sensor(val name: String, val room: String, val type: String, val zone: String)

@Composable
private fun BolidApp(prefs: android.content.SharedPreferences) {
    var pin by remember { mutableStateOf("") }
    var loggedIn by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("home") }
    var isAdmin by remember { mutableStateOf(true) }
    var users by remember { mutableStateOf(listOf("Администратор", "Пользователь 2")) }
    var sensors by remember { mutableStateOf(loadSensors(prefs)) }
    var alarmSound by remember { mutableStateOf(prefs.getBoolean("alarm_sound", true)) }
    var ventilation by remember { mutableStateOf(false) }
    var boiler by remember { mutableStateOf(false) }
    var pumpOn by remember { mutableStateOf(true) }
    var pumpFault by remember { mutableStateOf(false) }
    var newSensorName by remember { mutableStateOf("") }
    var newSensorRoom by remember { mutableStateOf("") }
    var newSensorType by remember { mutableStateOf("Пожарный извещатель") }
    var newSensorZone by remember { mutableStateOf("Пожарная") }
    var showDeleteIndex by remember { mutableStateOf<Int?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF174A70), secondary = Color(0xFF287A68))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF3F6F8)) {
            if (!loggedIn) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.Home, null, tint = Color(0xFF174A70), modifier = Modifier.size(60.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Безопасность дома", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("BolidHome 0.2 · демонстрационная версия", color = Color.Gray)
                    Spacer(Modifier.height(24.dp))
                    OutlinedTextField(
                        value = pin, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                        label = { Text("PIN-код (4 цифры)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { loggedIn = true }, enabled = pin.length == 4) { Text("Войти") }
                    Text("Демо: принимается любой PIN из 4 цифр", color = Color.Gray, fontSize = 12.sp)
                }
            } else {
                when (page) {
                    "home" -> HomePage(
                        onSection = { page = it.name.lowercase() },
                        onSettings = { page = "settings" }
                    )
                    "fire" -> DetailPage("Пожарная сигнализация", onBack = { page = "home" }) {
                        InfoCard("Состояние пожарных зон", "Неизвестно", "Оборудование не подключено")
                        InfoCard("Тревоги и неисправности", "Нет данных", "Это демонстрационный экран")
                        Text("Отключение звукового оповещения", fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Разрешить звуковое оповещение", Modifier.weight(1f))
                            Switch(alarmSound, { alarmSound = it; prefs.edit().putBoolean("alarm_sound", it).apply() })
                        }
                        Text("Изменение этого переключателя не управляет реальной пожарной автоматикой.", color = Color.Gray, fontSize = 12.sp)
                    }
                    "security" -> DetailPage("Охранная сигнализация", onBack = { page = "home" }) {
                        InfoCard("Охранные разделы", "Неизвестно", "Нет связи с оборудованием")
                        Text("Команды постановки и снятия охраны будут подключены после проверки протокола.", color = Color.Gray)
                    }
                    "access" -> DetailPage("Доступ", onBack = { page = "home" }) {
                        InfoCard("Входная дверь", "Состояние неизвестно", "Геркон не подтверждает запирание замка")
                        InfoCard("Калитка", "Состояние неизвестно", "Контроллер не подключён")
                        InfoCard("Ворота DoorHan", "Состояние неизвестно", "Предусматривается управление через штатный вход платы")
                    }
                    "actuators" -> DetailPage("Исполнительные устройства", onBack = { page = "home" }) {
                        ToggleRow("Вентиляция", ventilation) { ventilation = it }
                        Divider()
                        ToggleRow("Электрический котёл", boiler) { boiler = it }
                        Divider()
                        Text("Электронасос", fontWeight = FontWeight.Bold)
                        Text("Состояние: ${if (pumpOn) "включён (демо)" else "выключен (демо)"}")
                        Text("Авария: ${if (pumpFault) "есть (демо)" else "нет сигнала аварии (демо)"}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { pumpOn = !pumpOn }) { Text("Вкл./выкл. (демо)") }
                            OutlinedButton(onClick = { pumpFault = !pumpFault }) { Text("Авария (демо)") }
                        }
                    }
                    "settings" -> DetailPage("Настройки", onBack = { page = "home" }) {
                        SettingsItem("Пользователи", "До 5 пользователей · индивидуальные права") { page = "users" }
                        SettingsItem("Конфигурация датчиков", "Добавление и удаление — только администратор") { page = "sensors" }
                        SettingsItem("Журнал тревог", "Хранение 30 дней") { page = "alarms" }
                        SettingsItem("Оповещения", "Настройки звукового оповещения") { page = "notifications" }
                        SettingsItem("Связь", "WireGuard VPN · пока не настроено") { page = "connection" }
                    }
                    "users" -> DetailPage("Пользователи", onBack = { page = "settings" }) {
                        Text("Управление доступно администратору. В демо-версии PIN и права не являются реальной защитой.", color = Color.Gray, fontSize = 12.sp)
                        users.forEachIndexed { i, name ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(name, Modifier.weight(1f))
                                    Text(if (i == 0) "Администратор" else "Пользователь", color = Color.Gray, fontSize = 12.sp)
                                    if (i > 0 && isAdmin) IconButton(onClick = { users = users.filterIndexed { ix, _ -> ix != i } }) { Icon(Icons.Default.Delete, "Удалить") }
                                }
                            }
                        }
                        Button(onClick = { if (users.size < 5) users = users + "Пользователь ${users.size + 1}" }, enabled = users.size < 5 && isAdmin) { Text("Добавить пользователя") }
                    }
                    "sensors" -> DetailPage("Конфигурация датчиков", onBack = { page = "settings" }) {
                        Text("Каталог хранится локально на этом телефоне. Изменение каталога не перепрограммирует приборы «Болид».", color = Color.Gray, fontSize = 12.sp)
                        sensors.forEachIndexed { index, sensor ->
                            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(sensor.name, fontWeight = FontWeight.SemiBold)
                                        Text("${sensor.type} · ${sensor.room} · ${sensor.zone}", color = Color.Gray, fontSize = 12.sp)
                                    }
                                    if (isAdmin) IconButton(onClick = { showDeleteIndex = index }) { Icon(Icons.Default.Delete, "Удалить из каталога") }
                                }
                            }
                        }
                        if (isAdmin) {
                            Text("Добавить датчик", fontWeight = FontWeight.Bold)
                            OutlinedTextField(newSensorName, { newSensorName = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newSensorRoom, { newSensorRoom = it }, label = { Text("Этаж / помещение") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newSensorType, { newSensorType = it }, label = { Text("Тип датчика") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(newSensorZone, { newSensorZone = it }, label = { Text("Зона") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = {
                                if (newSensorName.isNotBlank() && newSensorRoom.isNotBlank()) {
                                    sensors = sensors + Sensor(newSensorName, newSensorRoom, newSensorType, newSensorZone)
                                    saveSensors(prefs, sensors)
                                    newSensorName = ""; newSensorRoom = ""
                                }
                            }, enabled = newSensorName.isNotBlank() && newSensorRoom.isNotBlank()) { Text("Добавить в каталог") }
                        }
                    }
                    "alarms" -> DetailPage("Журнал тревог", onBack = { page = "settings" }) {
                        InfoCard("Журнал", "Нет зарегистрированных событий", "Демонстрационная версия · хранение до 30 дней")
                        Text("События реального оборудования появятся после подключения и проверки протокола.", color = Color.Gray, fontSize = 12.sp)
                    }
                    "notifications" -> DetailPage("Оповещения", onBack = { page = "settings" }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Звуковое оповещение", Modifier.weight(1f))
                            Switch(alarmSound, { alarmSound = it; prefs.edit().putBoolean("alarm_sound", it).apply() })
                        }
                        Text("Мигающая кнопка раздела при тревоге будет реализована при подключении реальных событий. Пожарные алгоритмы не отключаются настройками телефона.", color = Color.Gray, fontSize = 12.sp)
                    }
                    "connection" -> DetailPage("Связь с домом", onBack = { page = "settings" }) {
                        InfoCard("WireGuard VPN", "Не настроено", "Параметры подключения пока отсутствуют")
                        InfoCard("С2000-Ethernet / С2000М", "Не подключено", "Совместимость и протокол требуют стендовой проверки")
                    }
                    else -> HomePage({ page = it.name.lowercase() }, { page = "settings" })
                }
                if (showDeleteIndex != null) {
                    AlertDialog(
                        onDismissRequest = { showDeleteIndex = null },
                        title = { Text("Удалить датчик из каталога?") },
                        text = { Text("Физическое устройство не отключается. Изменение касается только списка приложения.") },
                        confirmButton = {
                            TextButton(onClick = {
                                val ix = showDeleteIndex!!
                                sensors = sensors.filterIndexed { i, _ -> i != ix }
                                saveSensors(prefs, sensors)
                                showDeleteIndex = null
                            }) { Text("Удалить") }
                        },
                        dismissButton = { TextButton(onClick = { showDeleteIndex = null }) { Text("Отмена") } }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomePage(onSection: (Section) -> Unit, onSettings: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Система безопасности дома", fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("BolidHome 0.2 · POCO X6 5G", color = Color.Gray)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0D5))) {
                Text("ДЕМО-РЕЖИМ · связь с оборудованием отсутствует, команды не отправляются",
                    Modifier.padding(12.dp), color = Color(0xFF805000), fontSize = 13.sp)
            }
        }
        items(Section.entries) { item ->
            Card(
                Modifier.fillMaxWidth().clickable { onSection(item) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(item.icon, null, tint = Color(0xFF174A70), modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(16.dp))
                    Text(item.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item {
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("Настройки")
            }
        }
    }
}

@Composable
private fun DetailPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад") }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
private fun InfoCard(title: String, status: String, note: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(status, color = Color(0xFF9A5B00), modifier = Modifier.padding(top = 5.dp))
            Text(note, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(if (checked) "Включена (демо)" else "Выключена (демо)", color = Color.Gray, fontSize = 12.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun SettingsItem(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

private fun loadSensors(prefs: android.content.SharedPreferences): List<Sensor> {
    val raw = prefs.getString("sensors_json", null) ?: return listOf(
        Sensor("Дымовой извещатель", "1 этаж · холл", "Пожарный", "Пожарная"),
        Sensor("Геркон входной двери", "1 этаж · вход", "Охранный", "Периметр"),
        Sensor("Геркон калитки", "Участок", "Охранный", "Периметр")
    )
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Sensor(o.getString("name"), o.getString("room"), o.getString("type"), o.getString("zone"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveSensors(prefs: android.content.SharedPreferences, sensors: List<Sensor>) {
    val arr = JSONArray()
    sensors.forEach { s ->
        arr.put(JSONObject().put("name", s.name).put("room", s.room).put("type", s.type).put("zone", s.zone))
    }
    prefs.edit().putString("sensors_json", arr.toString()).apply()
}
